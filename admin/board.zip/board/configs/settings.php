<?php
/*
Файл для настроекс сайта
*/

// название сайта
//$siteName = "Веб чат";

$user_id = null;

if(isset($_COOKIE["user_id"])){
	$user_id = $_COOKIE["user_id"];
}

?>