<?php

	setcookie("user_id", "" , 0);
	header("Location: /");
?>
<!-- <a href="/">Главная</a> -->