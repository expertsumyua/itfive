<?php
	include "configs/db.php";

	$searchText = $_POST["search-text"];

	include 'modules/listContacts.php';
?>